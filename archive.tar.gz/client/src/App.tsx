import { Button } from "@nextui-org/react"

const App = () => {
  return (
    <div>
      <Button color="primary">Dima</Button>
    </div>
  )
}

export default App
